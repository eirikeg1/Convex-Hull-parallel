
public class Hashmap<T1, T2> {

}
