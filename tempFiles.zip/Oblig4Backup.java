import java.util.ArrayList;

public class Oblig4Backup {
    // Hashmaps to store runtimes
    Hashmap<Integer, ArrayList<Integer>> runtimesSeq = new Hashmap<>();
    Hashmap<Integer, ArrayList<Integer>> runtimesPar = new Hashmap<>();
    Hashmap<Integer, ArrayList<Double>> speedups = new Hashmap<>();

    // These values of n will be used if n is set to -1
    int[] nValues = { 1000, 10000, 100000, 1000000, 10000000 };

    public static void main(String[] args) {

        int n;
        int SEED;

        try {
            n = Integer.parseInt(args[0]);

            if (args.length > 1)
                SEED = Integer.parseInt(args[1]);
            else
                SEED = 0;

        } catch (Exception e) {
            System.out.println(
                    "Usage: 'java Oblig4 <n> [seed]', where <n> is the number of points to generate. Seed is optional.");
            return;
        }

        // Generate points
        int[] x = new int[n];
        int[] y = new int[n];

        NPunkter17 p = new NPunkter17(n, SEED);
        p.fyllArrayer(x, y);

        // Sequential version
        long start = System.currentTimeMillis();
        ConvexHull ch = new ConvexHull(n, x, y);
        IntList cohull = ch.findHullSeq();
        long end = System.currentTimeMillis();

        System.out.println("n: " + n + ", tid: " + (end - start) + " ms (sequential version)");
        // cohull.print();

        // Parallel version
        long startPar = System.currentTimeMillis();
        ConvexHull chPar = new ConvexHull(n, x, y);
        IntList cohullPar = ch.findHullPar();
        long endPar = System.currentTimeMillis();

        System.out.println("n: " + n + ", tid: " + (endPar - startPar) + " ms (parallel version)");
        // cohullPar.print();

        System.out.println("\nSpeedup: " + (double) (end - start) / (double) (endPar - startPar));

        if (n < 2000) {
            Oblig4Precode precode = new Oblig4Precode(chPar, cohullPar);
            precode.drawGraph();
        }

        // Draw results
        // Oblig4Precode precode = new Oblig4Precode(ch, cohull);
        // precode.drawGraph();

    }

}
